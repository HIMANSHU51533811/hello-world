package com.HBFramework.homepage;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.HBFramework.PageObject.LoginPage;
import com.HBFramework.helper.Logger.LoggerHelper;
import com.HBFramework.helper.Wait.WaitHelper;
import com.HBFramework.testbase.Config;
import com.HBFramework.testbase.baseTest;
 

public class LoginTest extends baseTest{
	private final Logger log = LoggerHelper.getLogger(LoginTest.class);

	@BeforeTest
	public void launchBrowser() throws Exception{
		try {
			loadPropertiesFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Config config = new Config(prop);
		getBrowser(config.getBrowser());
		WaitHelper waitHelper = new WaitHelper(driver);
		waitHelper.setImplicitWait(config.getImplicitWait(), TimeUnit.SECONDS);
		waitHelper.setPageLoadTimeout(config.getPageLoadTimeOut(), TimeUnit.SECONDS);
	}
	
	@Test
	public void testLoginToApplication() throws IOException{
		log.info(LoginTest.class.getName()+" @test has started");
		Config config = new Config(prop);
		driver.get(config.getWebsite());
		LoginPage login= new LoginPage(driver);
		login.loginToApplication(config.getUsername(), config.getPassword());
		boolean status=	login.verifySuccessLoginMsg();
		if (status) {
			log.info("login sucess");
		}else{
			testfail("Login failed");
			Assert.assertTrue(false, "login failed");
			
		}
	}
	
	

}
