package com.HBFramework.testbase;

import java.util.Properties;

public class Config extends baseTest{

	Properties prop;
	public Config(Properties prop){
		this.prop = prop;
	}
	public String getUsername(){
		return prop.getProperty("Username");
	}
	public String getPassword(){
		return prop.getProperty("Password");
	}
	public String getBrowser(){
		return prop.getProperty("Browser");
	}
	public String getWebsite(){
		return prop.getProperty("Website");
	}
	public int getImplicitWait() {
		return Integer.parseInt(prop.getProperty("ImplcitWait"));
	}
	public int getExplicitWait() {
		return Integer.parseInt(prop.getProperty("ExplicitWait"));
	}
	public int getPageLoadTimeOut() {
		return Integer.parseInt(prop.getProperty("PageLoadTimeOut"));
	}
}
