package com.HBFramework.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.HBFramework.excel_lib.ExcelApiLib;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class baseTest {
	public static final Logger logger = Logger.getLogger(baseTest.class.getName());
	public static WebDriver driver;
	public static  Properties prop;
	public static FileInputStream file;
	public static   ExtentReports extent=null;
	public static  ExtentTest test;
	static ExcelApiLib eal;

	//public ITestResult result; (testng interface)

	static {
		Calendar cal =Calendar.getInstance();
		SimpleDateFormat formater= new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		if (extent==null) {
			extent= new ExtentReports(System.getProperty("user.dir")+ "\\src\\main\\java\\com\\HBFramework\\reports\\REPORT_"+formater.format(cal.getTime())+".html" ,false, DisplayOrder.NEWEST_FIRST);
		}
	}
	
	/*@BeforeTest
	public void launchBrowser() throws IOException{
		Config config= new Config();
		getBrowser(config.getBrowser());
		WaitHelper wait = new WaitHelper(driver);
		wait.setImplicitWait(config.getImplicitWait(), TimeUnit.SECONDS);
		wait.setPageLoadTimeout(config.getPageLoadTimeOut(), TimeUnit.SECONDS);
	}*/

	public void getBrowser(String browserType) throws IOException{
		try {
			if (System.getProperty("os.name").contains("Window")) {
				if(driver==null){
					if (browserType.equalsIgnoreCase("IE")) {
						System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+ "\\drivers\\IEDriverServer.exe");
						driver = new InternetExplorerDriver();
					}else if(browserType.equalsIgnoreCase("chrome")){	
						System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
						driver= new ChromeDriver();	
					}else if(browserType.equalsIgnoreCase("FF")){
						System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"\\drivers\\geckodriver.exe");
						driver = new FirefoxDriver();
					}
					driver.manage().window().maximize();
					driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				}		
			}
		}
		catch (Exception e) {
			testfail("invalid browserType!!");
			//Assert.fail();
		}


	}
	public void loadPropertiesFile() throws Exception{	
		try {
			prop=new Properties();
			String filePath = System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\config\\config.properties";
			file=new FileInputStream(filePath);
			prop.load(file);
			logger.info("In basetest config.properties has loaded");
		} catch (Exception e) {		
			e.printStackTrace();
			test.log(LogStatus.FAIL, "invalid config property name!!");
			getScreenShot("configError");
			//Assert.fail();
		}
		String filePath1 = System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\config\\OR.properties";
		file = new FileInputStream(filePath1);
		prop.load(file);
		logger.info("In basetest OR.properties has loaded");
	}

	public String getScreenShot(String scrshtnm) throws IOException {
		if (scrshtnm=="") 
		{
			scrshtnm= "blank_error";	
		}
		File f =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String imageLocation= System.getProperty("user.dir")+ "\\src\\main\\java\\com\\HBFramework\\screenshots\\"; 
		Calendar cal =Calendar.getInstance();
		SimpleDateFormat formater= new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String screenshotPath=imageLocation+scrshtnm+"_"+formater.format(cal.getTime())+".PNG";
		FileUtils.copyFile(f, new File(screenshotPath));
		return screenshotPath;
	}

	public WebElement waitForElement(WebDriver ldriver, long time, WebElement element){
		WebDriverWait wait= new WebDriverWait(ldriver, time);
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public WebElement waitForElementWithPollingInterval(WebDriver ldriver, long time, WebElement element){
		WebDriverWait wait= new WebDriverWait(ldriver, time);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		wait.ignoring(NoSuchElementException.class);
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public void implicitWait(long time){
		driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
	}

	/*
	 * reporting methods
	 */
	public void testpass(String message){
		test.log(LogStatus.PASS, message);
		logger.info("testpass(String message): has loaded");
	}

	public void testfail(String message) throws IOException{
		String screen = getScreenShot(message);
		test.log(LogStatus.FAIL, test.addScreenCapture(screen));
	}

	public void testinfo(String message){
		test.log(LogStatus.INFO, message);
		logger.info("testinfo(String message): has loaded");
	}

	/*@AfterClass(alwaysRun=true)
	public void endTest(){
		driver.quit();
		extent.endTest(test);
		extent.flush();
		logger.info("AfterCLASS endTest(): has called");
	}*/
	
	@BeforeMethod	//need to chk better approach
	public static void tearup() {
		test = extent.startTest(" StartTest Started");
		test.log(LogStatus.INFO,  " INFO:test has Started");
	}
	
	@AfterMethod(alwaysRun=true)
	public void teardown(){
		extent.endTest(test);
		extent.flush();		
	}
	
	@AfterClass
	public void close(){
		driver.quit();
	}

	public void navigator(String appUrl){
		driver.navigate().to(prop.getProperty(appUrl));
	}

	public void switchwindow(int index){
		driver.switchTo().frame(index);	
	}

	public WebElement getElement(String locatorkey) throws IOException{
		try {
			if (locatorkey.endsWith("_xpath")) {
				return driver.findElement(By.xpath(locatorkey));}
			if (locatorkey.endsWith("_id")) {
				return driver.findElement(By.xpath(locatorkey));}
			if (locatorkey.endsWith("_name")) {
				return driver.findElement(By.xpath(locatorkey));}
			else{
				System.out.println("locator not correct!!");
				test.log(LogStatus.FAIL, "invalid locator provided!!");
				//testfail(locatorkey+"invalid locator provided!!");	 // testfail() chetan created			
				return null;
			}
		} catch (Exception e) {
			testfail("invalid browserType!!");
			return null;
		}
	}

	public void setText(String locatorkey, String inpputtext) throws IOException{
		WebElement wEle= getElement(locatorkey);
		wEle.clear();
		wEle.sendKeys(inpputtext);
	}
	public void click(String locatorkey) throws IOException{
		WebElement wEle= getElement(locatorkey);
		wEle.click();

	}
	public void JS_click(String locatorKey) throws IOException{
		WebElement elm=getElement(locatorKey);
		JavascriptExecutor JS=(JavascriptExecutor)driver;
		JS.executeScript("arguments[0].click();", elm);
	}

	public boolean verifyText(String actValue,String expValue){
		if(actValue.equals(expValue)){
			return true;
		}else{
			return false;
		}
	}

	public Object[][] getExcelData(String xlFilePath, String sheetName) throws Exception{
		String log4jConfPath ="log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
		Object[][] excelData = null;
		eal = new ExcelApiLib(xlFilePath);
		int rows = eal.getRowCount(sheetName);
		int columns = eal.getColumnCount(sheetName);

		excelData = new Object[rows-1][columns];	
		for(int i=1; i<rows; i++)
		{
			for(int j=0; j<columns; j++)
			{
				excelData[i-1][j] = eal.getCellData(sheetName, j, i);
			}
		}
		return excelData;
	}
	public static String TDPATH(String xlName){
		String xlFilePath =System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\testdata\\"+xlName;
		return xlFilePath;
	}


	public static void main(String[] args) throws Exception {
		baseTest b1 = new baseTest();
		b1.loadPropertiesFile();
		System.out.println(prop.getProperty("url"));

	}
}


