package com.HBFramework.testbase;

import com.HBFramework.excel_lib.ExcelApiLib;


public class baseTest2 {
	static ExcelApiLib eal= null;
	public Object[][] getExcelData(String xlFilePath, String sheetName) throws Exception{
		Object[][] excelData = null;
		eal = new ExcelApiLib(xlFilePath);
		int rows = eal.getRowCount(sheetName);
		int columns = eal.getColumnCount(sheetName);

		excelData = new Object[rows-1][columns];		//rows-1 because skip the header of excel
		for(int i=1; i<rows; i++)
		{
			for(int j=0; j<columns; j++)
			{
				excelData[i-1][j] = eal.getCellData(sheetName, j, i);//left side is 2d array,where we are storing the val which is -1 from parent(line 41)
			}
		}
		return excelData;
	}
	public static String TEST(String xlName){
		String xlFilePath =System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\testdata\\"+xlName;
		return xlFilePath;
	}
}


