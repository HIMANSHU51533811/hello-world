package com.HBFramework.excel_lib;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Hashtable;

public class myexcel_Reader {
	public static FileInputStream file = null;
	public static FileOutputStream out = null;
	private static XSSFWorkbook WB = null;
	private static XSSFSheet data = null;
	private static XSSFRow row = null;
	//private static XSSFCell cell = null;
	static Hashtable<Object, Object> dict;

	//class constructor
	public myexcel_Reader(String filePath) {
		try {
			file = new FileInputStream(filePath);
			WB = new XSSFWorkbook(file);
			//data =WB.getSheetAt(0);
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// returns the row count in a sheet
	public  int getRowCount(String sheetname) {
		int index = WB.getSheetIndex(sheetname	);
		if (index==-1) {
			return 0;
		}
		else{
			data = WB.getSheetAt(index);
			int rc= data.getLastRowNum()+1;
			return rc;
		}
	}
	// find whether sheets exists
	public static boolean isSheetExist(String sheetname) {
		int index = WB.getSheetIndex(sheetname);
		if (index == -1) {
			index = WB.getSheetIndex(sheetname.toUpperCase());
			if (index == -1)
				return false;
			else
				return true;
		} else
			return true;
	}

	// returns number of columns in a sheet
	public  int getColumnCount(String sheetname) {
		// check if sheet exists
		if (!isSheetExist(sheetname))
			return -1;
		data = WB.getSheet(sheetname);
		row = data.getRow(0);							//row is obj of XSSFRow
		if (row == null){
			return -1;
		}
		return row.getLastCellNum();		
	}


	public  String getCellData(String sheetname, int row, int col) {
		data = WB.getSheet(sheetname);
		String cellValue = data.getRow(row).getCell(col).getStringCellValue();
		return cellValue;
	}
	
	
	//insert all data rows in object array in the form of hashtables.
	//Object[][] data= new Object[datarows][1];

	//Create Column Dictionary to hold all the Column Names
	public  void columnDictionary(String sheetname) {
		//Iterate through all the cell in the Excel sheet and store the value in Hashtable
		int colcount = getColumnCount(sheetname);
			dict = new Hashtable<Object,Object>();
			for (int j = 0; j < colcount; j++) {
				//cell= row.getCell(j);					//cell is obj of XSSFCell
				dict.put(getCellData(sheetname, 0, j), j);
			}
		}
	//}
	public  int getCellIndex(String colName) {
		try {
			int value;
			value = ((Integer) dict.get(colName)).intValue();
			return value;
		} catch (NullPointerException e) {
			return (0);
		}
	}
	
	/*public static void writeCell(int i, String status) throws Exception{
		data.getRow(i).createCell(2).setCellValue(status);
	}

	public static void tiredUp() throws Exception{
		out = new FileOutputStream("D:\\Users\\goswami.h\\workspace\\myFrameworkAutoProj\\testdata\\ReadExcelDataMyHCL.xlsx");
		WB.write(out);
		WB.close();
	}*/
}
