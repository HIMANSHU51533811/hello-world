package com.HBFramework.excel_lib;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class junkExcel_reader {

	@SuppressWarnings("deprecation")
	public String[][] readExcelData(String excellocation, String sheetname) {
		String[] [] dataset;
		try {
			FileInputStream fis = new FileInputStream(excellocation);
			Workbook WB =new XSSFWorkbook(fis);
			Sheet data=WB.getSheet(sheetname);
			int rowcount = data.getLastRowNum()+1;
			int cellCount = data.getRow(0).getLastCellNum();
			dataset = new String[rowcount-1][cellCount];
			for (int i = 0; i <rowcount; i++) {
				//if (i!=0) {
					Row row = data.getRow(i);
					for (int j = 0; j < cellCount; j++) {
						Cell col= row.getCell(j);
						switch (col.getCellType()) {
						case Cell.CELL_TYPE_NUMERIC:
							/*System.out.print(i +",");
							System.out.print(j +"");*/
							System.out.println(" "+(int)col.getNumericCellValue()+ "  ");
							break;
						case Cell.CELL_TYPE_BOOLEAN:
							System.out.println(col.getBooleanCellValue()+ " ");
							break;
						case Cell.CELL_TYPE_STRING:
							/*System.out.print(i +",");
							System.out.print(j +"");*/
							System.out.println(" "+col.getStringCellValue()+ "  ");
							break;
						default:
							System.out.println("error");
							break;
						}
					}
					System.out.println();
				}
			//}
			fis.close();
			WB.close();
			
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return dataset;
	}
	public static void main(String[] args) {
		junkExcel_reader ee =new junkExcel_reader();
		ee.readExcelData(System.getProperty("user.dir")+"/src/main/java/com/HBFramework/testdata/ReadExcelDataZoho.xlsx", "LoginTestData");

	}
}



