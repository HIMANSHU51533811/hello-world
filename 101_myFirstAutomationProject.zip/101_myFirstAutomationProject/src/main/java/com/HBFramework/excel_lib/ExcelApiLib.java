package com.HBFramework.excel_lib;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelApiLib {
	public static final Logger logger = Logger.getLogger(ExcelApiLib.class.getName());
	public  FileInputStream fis = null;
	public  FileOutputStream fos = null;
	public  XSSFWorkbook wb = null;
	public  XSSFSheet data = null;
	public  XSSFRow row = null;
	public  XSSFCell cell = null;
	String xlFilePath;
	public Hashtable<Object, Object> dict;

	public ExcelApiLib(String xlFilePath){
		try {
			logger.info("create excel object "+xlFilePath);
			this.xlFilePath = xlFilePath;
			fis= new FileInputStream(xlFilePath);
			wb = new XSSFWorkbook(fis);
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int getRowCount(String sheetName)
	{
		data = wb.getSheet(sheetName);
		int rowCount = data.getLastRowNum()+1;
		return rowCount;
	}

	public int getColumnCount(String sheetName)
	{
		data = wb.getSheet(sheetName);
		row = data.getRow(0);
		int colCount = row.getLastCellNum();
		return colCount;
	}

	@SuppressWarnings("deprecation")
	public String getCellData(String sheetName, int colNum, int rowNum) {
		try {
			data=wb.getSheet(sheetName);
			row=data.getRow(rowNum);//rowNum-1 will give header while calling with rownum is 1
			cell=row.getCell(colNum);
			if (cell.getCellTypeEnum()==CellType.STRING) {
				return cell.getStringCellValue();	
			}else if(cell.getCellTypeEnum()==CellType.NUMERIC || cell.getCellTypeEnum()==CellType.FORMULA){
				String cellValue= String.valueOf(cell.getNumericCellValue());
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					DateFormat df =	new SimpleDateFormat("dd/MM/yy");
					Date date=cell.getDateCellValue();
					cellValue =df.format(date);
				}
				return cellValue;
			}else if (cell.getCellTypeEnum()==CellType.BLANK) {
				return "";
			}else
				return String.valueOf(cell.getBooleanCellValue());
		} catch (Exception e) {
			e.printStackTrace();
			return "the row no:- "+rowNum+" the column no:- "+colNum+ " does not exist  in Excel";
		}
	}

	@SuppressWarnings("deprecation")
	public String getCellData(String sheetName, String colName, int rowNum) {
		try{
			int col_Num = -1;
			data=wb.getSheet(sheetName);
			row = data.getRow(0);
			for(int i = 0; i < row.getLastCellNum(); i++)
			{
				if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
					col_Num = i;
			}
			row = data.getRow(rowNum-1);
			cell = row.getCell(col_Num);
			if(cell.getCellTypeEnum() == CellType.STRING)
				return cell.getStringCellValue();
			else if(cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA)
			{
				String cellValue = String.valueOf(cell.getNumericCellValue());
				if(HSSFDateUtil.isCellDateFormatted(cell))
				{
					DateFormat df = new SimpleDateFormat("dd/MM/yy");
					Date date = cell.getDateCellValue();
					cellValue = df.format(date);
				}
				return cellValue;
			}else if(cell.getCellTypeEnum() == CellType.BLANK)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());
		}
		catch(Exception e){
			e.printStackTrace();
			return "the row no:- "+rowNum+" the column name no:- "+colName + " does not exist  in Excel";
		}
	}

	public boolean setCellData(String sheetName, int colNumber, int rowNum, String value){
		try {
			data = wb.getSheet(sheetName);
			row= data.getRow(rowNum);
			if (row==null) 
				row= data.createRow(rowNum);	
			cell = row.getCell(colNumber);
			if (cell==null) 
				cell= row.createCell(colNumber);
			cell.setCellValue(value);

			fos =new FileOutputStream(xlFilePath);
			wb.write(fos);
			fos.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	 
	}

	public boolean setCellData(String sheetName, String colName, int rowNum, String value){

		try {
			int col_Num = -1;
			data = wb.getSheet(sheetName);
			row = data.getRow(0);
			for(int i =0; i< row.getLastCellNum();i++){
				if (row.getCell(i).getStringCellValue().trim().equals(colName)) {
					col_Num  = i;
				}
			}
			row = data.getRow(rowNum-1);
			if (row==null) 
				row= data.createRow(rowNum-1);
			cell= row.getCell(col_Num);
			if (cell==null) 
				cell= row.createCell(col_Num);
			cell.setCellValue(value);

			fos =new FileOutputStream(xlFilePath);
			wb.write(fos);
			fos.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();		
			return false;
		} 

	}

}







