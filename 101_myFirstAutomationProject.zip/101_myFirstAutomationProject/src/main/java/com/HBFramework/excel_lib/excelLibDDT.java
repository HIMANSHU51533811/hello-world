package com.HBFramework.excel_lib;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Hashtable;

public class excelLibDDT {
	public static FileInputStream file = null;
	public static FileOutputStream out = null;
	public static XSSFWorkbook WB = null;
	public static XSSFSheet data = null;
	static Hashtable<Object, Object> dict = new Hashtable<Object, Object>();
	public excelLibDDT(String filePath) {
		try {
			file = new FileInputStream(filePath);
			WB = new XSSFWorkbook(file);
			data =WB.getSheetAt(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public  int RowCount() {
		int rc = data.getLastRowNum();
		return rc;
	}
	public int ColCount() {
		XSSFRow row = data.getRow(0);
		int cc = row.getLastCellNum();
		return cc;
	}
	public String ReadCell(int i, int j) {
		String cellValue = data.getRow(i).getCell(j).getStringCellValue();
		return cellValue;
	}

	public void writeCELL(int i, String status) throws Exception{
		data.getRow(i).createCell(2).setCellValue(status);
	}

	public  void tiredUp() throws Exception{
		out = new FileOutputStream("D:\\Users\\goswami.h\\workspace\\myFrameworkAutoProj\\testdata\\ReadExcelDataMyHCL.xlsx");
		WB.write(out);
		WB.close();
	}

	//Create Column Dictionary to hold all the Column Names
	public void ColumnDictionary() {
		//Iterate through all the cell in the Excel sheet and store the value in Hashtable
		for (int i = 0; i <= data.getLastRowNum(); i++) {
			XSSFRow row = data.getRow(i);
			int cellcount = row.getLastCellNum();
			//columns
			for (int j = 0; j < cellcount; j++) {
				//  XSSFCell col = row.getCell(j);
				dict.put(ReadCell(0, j), j);
			}
		}
	}
	public int GetCell(String colName) {
		try {
			int value;
			value = ((Integer) dict.get(colName)).intValue();
			return value;
		} catch (NullPointerException e) {
			return (0);

		}
	}
}
