package com.HBFramework.helper.browser;

import java.util.LinkedList;
import java.util.Set;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class BrowserHelper {
	private WebDriver driver;
	private Logger logger = Logger.getLogger(BrowserHelper.class.getName());

	public BrowserHelper(WebDriver driver) {
		this.driver= driver;
		logger.debug("BrowserHelper: "+this.driver.hashCode());
	}

	public void goBack(){
		driver.navigate().back();
		logger.info("");
	}

	public void goForward(){
		driver.navigate().forward();
		logger.info("");
	}

	public void goRefresh(){
		driver.navigate().refresh();
		logger.info("");
	}

	public Set<String> getWindowHandles(){
		logger.info("");
		return driver.getWindowHandles();
	}

	public void switchToWindow(int index){
		LinkedList<String> windowsId = new LinkedList<String>(getWindowHandles());

		if (index<0 || index> windowsId.size()) {
			throw new IllegalArgumentException("Invalid index :"+index);
		}
		driver.switchTo().window(windowsId.get(index));
		logger.info(index);
	}

	public void switchToParentWindow(){
		LinkedList<String> windowsId = new LinkedList<String>(getWindowHandles());
		driver.switchTo().window(windowsId.get(0));
		logger.info("");
	}

	public void switchToParentWithChildClose(){
		LinkedList<String> windowsId = new LinkedList<String>
		(getWindowHandles());
		for (int i = 1; i < windowsId.size(); i++) {
			driver.switchTo().window(windowsId.get(i));
			driver.close();
		}
		switchToParentWindow();	
	}

	public void switchToFrame(String name){
		driver.switchTo().frame(name);
		logger.info(name);
	}	
}


























