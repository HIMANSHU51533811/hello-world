package com.HBFramework.helper.Javascript;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.HBFramework.helper.Logger.LoggerHelper;

public class JavaScriptHelper {
	private WebDriver driver;
	private Logger logger = LoggerHelper.getLogger(JavaScriptHelper.class);

	public JavaScriptHelper(WebDriver driver) {
		this.driver=driver;
		logger.debug("JavaScriptHelper :"+this.driver.hashCode());
	}

	public Object executeScript(String scripts){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		Object ojs =js.executeScript(scripts);
		logger.info(scripts);
		return ojs;
	}

	public Object executeScript(String scripts, Object...arg ){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		Object ojs =js.executeScript(scripts, arg);
		logger.info(scripts);
		return ojs;
	}

	public void scrollToElement(WebElement ele){
		executeScript("window.scrollTo(arguments[0],arguments[1]", ele.getLocation().x,ele.getLocation().y);
		logger.info(ele);
	}

	public void scrollToElementAndClick(WebElement ele){
		scrollToElement(ele);
		ele.click();
		logger.info(ele);
	}

	public void scrollToView(WebElement ele){
		executeScript("arguments[0].scrollToView()", ele);		//scrollToView(true)
		logger.info(ele);
	}

	public void scrollToViewAndClick(WebElement ele){
		scrollToView(ele);
		ele.click();
		logger.info(ele);
	}

	public void scrollDownVertically(){
		executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public void scrollUpVertically(){
		executeScript("window.scrollTo(0, -document.body.scrollHeight)");
	}

	public void scrollDownByPixel(){
		executeScript("window.scrollBy(0, 1500)");
	}

	public void scrollUpByPixel(){
		executeScript("window.scrollBy(0, -1500)");
	}

	public void zoomByPercentage(){
		executeScript("document.body.style.zoom='40%')");
	}
}