package com.HBFramework.helper.genericHelper;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

public class GenericHelper {
	public Logger logger = Logger.getLogger(GenericHelper.class.getName());

	public String readValueFromWebelement(WebElement ele) {
		if (null==ele) {
			logger.info("webElement is Null ");
			return null;
		}
		boolean displayed =false;
		try {
			displayed= isDisplayed(ele);//isDisplayed in sel throws exception instead of gving false val so method has created
		} catch (Exception e) {
			logger.error("Element not present :"+e);
			return null;
		}
		if (!displayed) {
			return null;
		}
		String text= ele.getText();
		logger.info(text);
		return text;			
	}

	public String readValueFromInput(WebElement ele){

		if (null==ele) {
			return null;
		}
		if (!isDisplayed(ele)) {
			return null;
		}
		logger.info("Attribute value is :"+ele.getAttribute("value"));
		return ele.getAttribute("value");	
	}

	public boolean isDisplayed(WebElement ele) {
		try {
			ele.isDisplayed();
			logger.info("webElement is present :"+ele);
			return true;
		} catch (Exception e) {
			logger.error("webElement is Null");
			return false;
		}
	}

	public boolean isNotDisplayed(WebElement ele) {
		try {
			ele.isDisplayed();
			logger.info("webElement is present :"+ele);
			return false;
		} catch (Exception e) {
			logger.error("webElement is Null");
			return true;
		}
	}
}































