package com.HBFramework.helper.Wait;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.HBFramework.helper.Logger.LoggerHelper;

public class WaitHelper {
	private WebDriver driver;
	private Logger log = LoggerHelper.getLogger(WaitHelper.class);

	public WaitHelper(WebDriver driver){
		this.driver= driver;
		log.debug("WaitHelper :"+this.driver.hashCode());
	}

	public void setImplicitWait(long timeout, TimeUnit unit){
		log.info(timeout);
		driver.manage().timeouts().implicitlyWait(timeout, unit==null?TimeUnit.SECONDS :unit);
	}

	public void setPageLoadTimeout(long timeout, TimeUnit unit) {
		log.info(timeout);
		driver.manage().timeouts().pageLoadTimeout(timeout, unit == null ? TimeUnit.SECONDS : unit);
	}

	public WebDriverWait getWait(int timeOutInSeconds, int pollingEveryInMiliSec){
		log.info("");
		WebDriverWait wait =new WebDriverWait(driver, timeOutInSeconds);
		wait.pollingEvery(pollingEveryInMiliSec, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(ElementNotVisibleException.class);
		wait.ignoring(StaleElementReferenceException.class);
		return wait;
	}

	public void waitForElementVisible(WebElement locator,int timeOutInSeconds, int pollingEveryInMiliSec){
		log.info(locator);
		WebDriverWait wait = getWait(timeOutInSeconds, pollingEveryInMiliSec);
		wait.until(ExpectedConditions.visibilityOf(locator));
	}

	/*public void waitForElement(WebElement ele, long timeout){
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOf(ele));
		log.info("Element Found :"+ele.getText());
	}*/
	
	public void waitForElement(WebDriver driver, WebElement ele, long timeout){
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOf(ele));
		log.info("Element Found :"+ele.getText());
	}


	public WebElement waitForElement(WebDriver driver,long timeout, WebElement ele){
		log.info("Element Found :"+ele.getText());
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		return wait.until(ExpectedConditions.elementToBeClickable(ele));
	}

}
