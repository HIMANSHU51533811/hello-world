package com.HBFramework.helper.DropDown;

import java.util.LinkedList;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class DropDownHelper {
	private WebDriver driver;
	private Logger logger = Logger.getLogger(DropDownHelper.class.getName());

	public DropDownHelper(WebDriver driver) {
		this.driver= driver;
		logger.debug("DropDownHelper is :"+this.driver.hashCode());
	}

	public void selectUsingVisibleValue(WebElement ele, String val){
		new Select(ele).selectByVisibleText(val);
		logger.info("Locator is : "+ele+" value is :"+val);
	}

	public String getSelectValue(WebElement ele){
		String val = new Select(ele).getFirstSelectedOption().getText();
		logger.info("Locator is : "+ele+" value is :"+val);
		return val;

	}

	public void selectUsingIndex(WebElement ele, int index){
		new Select(ele).selectByIndex(index);
		logger.info("Locator is: "+ele+" index is : "+index);
	}

	public java.util.List<String> getAllDropDownValues(WebElement locator){
		Select sel= new Select(locator);
		java.util.List<WebElement> lsel= sel.getOptions();
		java.util.List<String> linklsel= new LinkedList<String>();

		for (WebElement webElement : lsel) {
			webElement.getText();
			linklsel.add(webElement.getText());
		}
		return linklsel;		
	}

}
