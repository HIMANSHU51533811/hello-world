package com.HBFramework.helper.assertionHelper;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;


public class VerificationHelper {

	private static Logger logger = Logger.getLogger(VerificationHelper.class.getName());
	public static synchronized boolean verifyElementPresent(WebElement ele){
		boolean isDisplay = false;
		try {
			isDisplay=ele.isDisplayed();
			logger.info(ele.getText()+" is displayed");
		} catch (Exception e) {
			logger.error("Element not found "+e);
		}
		return isDisplay;
	}

	public static synchronized boolean verifyElementNotPresent(WebElement ele){
		boolean isDisplay = false;
		try{
			isDisplay =ele.isDisplayed();
			logger.info(ele.getText()+" is displayed");	
		} catch(Exception e){
			logger.error("Element not found "+e);
			return true;
		}
		return isDisplay;	
	}

	public static synchronized boolean verifyTextEquals(WebElement ele, String expText){
		boolean flag = false;
		try {
			String actualText=ele.getText();
			if (actualText.equals(expText)) {
				logger.info("ActualText is :"+actualText+"ExpectText is :"+expText);
				return flag=true;	
			}else
			{
				logger.error("ActualText is :"+actualText+"ExpectText is :"+expText);
				return flag;
			}
		} catch (Exception e) {
			logger.error("ActualText is :"+ele.getText()+"ExpectText is :"+expText);
			logger.info("text is not matching "+e);
			return flag;
		}
	}
}
