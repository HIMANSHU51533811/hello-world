package com.HBFramework.helper.Alert;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;

public class AlertHelper {
	private WebDriver driver;
	private Logger logger = Logger.getLogger(AlertHelper.class.getName());
	public AlertHelper(WebDriver driver) {
		this.driver=driver;
		logger.debug("AlertHelper: "+this.driver.hashCode());
	}
	public Alert getAlert(){
		logger.debug("");
		return driver.switchTo().alert();
	}

	public void acceptAlert(){
		logger.debug("");
		//driver.switchTo().alert().accept();
		/* Alert aa= getAlert();
		 aa.accept();*/
		getAlert().accept();
	}

	public void dismissAlert(){
		logger.debug("");
		getAlert().dismiss();
	}

	public String getAlertText() {
		String text= getAlert().getText();
		return text;
	}

	public boolean isAlertPresent(){
		try {
			driver.switchTo().alert();
			logger.info("true");
			return true;
		} catch (NoAlertPresentException e) {
			//ignore
			logger.info("false");
			return false;
		}
	}

	public void acceptAlertIfPresent(){
		if (!isAlertPresent()) 
			return;
		acceptAlert();
		logger.info("");	
	}

	public void dismissAlertIfPresent(){
		if (!isAlertPresent()) 
			return;
		dismissAlert();
		logger.info("");	
	}

	public void acceptPromt(String msg){
		if (!isAlertPresent()) {
			return;
		}
		getAlert().sendKeys(msg);
		getAlert().accept();
		logger.info(msg);
	}
}	

























