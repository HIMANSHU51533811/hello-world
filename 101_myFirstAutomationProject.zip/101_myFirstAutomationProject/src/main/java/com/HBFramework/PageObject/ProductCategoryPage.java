package com.HBFramework.PageObject;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.HBFramework.helper.Logger.LoggerHelper;
import com.HBFramework.helper.Wait.WaitHelper;

public class ProductCategoryPage {
	WebDriver driver;
	public Logger log = LoggerHelper.getLogger(ProductCategoryPage.class);
	WaitHelper wait;

	public ProductCategoryPage(WebDriver driver) {
		this.driver=driver;
	}

}
