package com.HBFramework.PageObject;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.HBFramework.helper.Logger.LoggerHelper;
import com.HBFramework.helper.Wait.WaitHelper;
import com.HBFramework.testbase.Config;
import com.HBFramework.testbase.baseTest;

public class RegistrationPage {

	WebDriver driver;
	public Logger log = LoggerHelper.getLogger(RegistrationPage.class);
	WaitHelper wait;

	@FindBy(xpath=".//*[@id='id_gender1']")
	WebElement mrRadioBtn;

	@FindBy(xpath=".//*[@id='id_gender2']")
	WebElement mrsRadioBtn;

	@FindBy(xpath=".//*[@id='customer_firstname']")
	WebElement firstName;

	@FindBy(xpath=".//*[@id='customer_lastname']")   
	WebElement lastName; 

	@FindBy(xpath=".//*[@id='email']")
	WebElement emailaddress;

	@FindBy(xpath=".//*[@id='passwd']")
	WebElement password;

	@FindBy(xpath=".//*[@id='days']")
	WebElement days;

	@FindBy(xpath=".//*[@id='months']")
	WebElement months;

	@FindBy(xpath=".//*[@id='years']")
	WebElement years;

	@FindBy(xpath=".//*[@id='firstname']")
	WebElement yourAddrFirstName;

	@FindBy(xpath=".//*[@id='lastname']")
	WebElement yourAddrLastName;

	@FindBy(xpath=".//*[@id='company']")
	WebElement yourAddrcompany;

	@FindBy(xpath=".//*[@id='address1']")
	WebElement	address1;

	@FindBy(xpath=".//*[@id='address2']")
	WebElement address2;					

	@FindBy(xpath=".//*[@id='city']")
	WebElement	youAddrCity;

	@FindBy(xpath=".//*[@id='id_state']")
	WebElement yourAddrState;

	@FindBy(xpath=".//*[@id='postcode']")
	WebElement yourAddrPostalCode;

	@FindBy(xpath=".//*[@id='id_country']")
	WebElement addtionalInformaition;

	@FindBy(xpath=".//*[@id='phone']")
	WebElement homePhone;

	@FindBy(xpath=".//*[@id='phone_mobile']")
	WebElement mobilePhone;

	@FindBy(xpath=".//*[@id='alias']")
	WebElement addrAlias;

	@FindBy(xpath=".//*[@id='submitAccount']")
	WebElement submitAccountRegistration;

	public RegistrationPage(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
		wait=new WaitHelper(driver);
		wait.waitForElement(driver, mrRadioBtn, new Config(baseTest.prop).getExplicitWait());
	}

	public void setMrRadioButton(){
		log.info("selecting Mr checkbox...");
		this.mrRadioBtn.click();
	}

	public void setMrsRadioButton(){
		log.info("selecting Mr checkbox...");
		this.mrsRadioBtn.click();
	}

	public void setFirstName(String firstName){
		log.info("entering firstName..:"+firstName);
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName){
		log.info("entering lastName..:"+lastName);
		this.lastName.sendKeys(lastName);
	}

	public void setEmailAddress(String emailaddress){
		log.info("entering emailaddress..:"+emailaddress);
		this.emailaddress.sendKeys(emailaddress);
	}

	public void setPassword(String password){
		log.info("entering password..:"+password);
		this.password.sendKeys(password);
	}

	public void setDay(String day){
		List<WebElement> days= driver.findElements(By.xpath(".//*[@id='days']/option"));
		Iterator<WebElement> itr =days.iterator();
		while (itr.hasNext()) {
			WebElement webEle = (WebElement) itr.next();
			String text= webEle.getText().trim().toString();
			if (text.equals(day)) {
				webEle.click();
				break;
			}	
		}
	}

	public void setMonth(String month){
		List<WebElement> months= driver.findElements(By.xpath(".//*[@id='months']/option"));
		Iterator<WebElement> itr =months.iterator();
		while (itr.hasNext()) {
			WebElement webEle = (WebElement) itr.next();
			String text= webEle.getText().trim().toString();
			if (text.equals(month)) {
				webEle.click();
				break;
			}	
		}
	}

	public void setYear(String year){
		List<WebElement> years= driver.findElements(By.xpath(".//*[@id='years']/option"));
		Iterator<WebElement> itr =years.iterator();
		while (itr.hasNext()) {
			WebElement webEle = (WebElement) itr.next();
			String text= webEle.getText().trim().toString();
			if (text.equals(year)) {
				webEle.click();
				break;
			}	
		}
	}

	public void setYourAddrFirstName(String yourAddrFirstName){
		log.info("entering yourAddrFirstName..:"+yourAddrFirstName);
		this.yourAddrFirstName.sendKeys(yourAddrFirstName);
	}

	public void setYourAddrLastName(String yourAddrLastName){
		log.info("entering yourAddrLastName..:"+yourAddrLastName);
		this.yourAddrLastName.sendKeys(yourAddrLastName);
	}

	public void setYourAddrCompany(String yourAddrcompany){
		log.info("entering setYourAddrCompany..:"+yourAddrcompany);
		this.yourAddrcompany.sendKeys(yourAddrcompany);
	}

	public void setYourAddress1(String address1){
		log.info("entering setYourAddress1..:"+address1);
		this.address1.sendKeys(address1);
	}

	public void setYourAddress2(String address2){
		log.info("entering setYourAddress2..:"+address2);
		this.address2.sendKeys(address2);  
	}   

	public void setYourAddrCity(String youAddrCity){
		log.info("entering youAddrCity..:"+youAddrCity);
		this.youAddrCity.sendKeys(youAddrCity);
	}

	public void setYourAddrState(String yourAddrState){
		log.info("entering yourAddrState..:"+yourAddrState);
		this.yourAddrState.sendKeys(yourAddrState);
	}

	public void setYourAddrPostalCode(String yourAddrPostalCode){
		log.info("entering yourAddrPostalCode..:"+yourAddrPostalCode);
		this.yourAddrPostalCode.sendKeys(yourAddrPostalCode);
	}

	public void setYourAddtionalInformaition(String addtionalInformaition){
		log.info("entering addtionalInformaition for country..:"+addtionalInformaition);
		this.addtionalInformaition.sendKeys(addtionalInformaition);
	}

	public void setHomePhone(String homePhone){
		log.info("entering homePhone..:"+homePhone);
		this.homePhone.sendKeys(homePhone);
	}

	public void setMobilePhone(String mobilePhone){
		log.info("entering mobilePhone..:"+mobilePhone);
		this.mobilePhone.sendKeys(mobilePhone);	
	}

	public void setAddrAlias(String addrAlias){
		log.info("entering addrAlias..:"+addrAlias);
		this.addrAlias.sendKeys(addrAlias);
	}

	public void clickAccountRegistration(String submitAccountRegistration){
		log.info("entering submitAccountRegistration..:"+submitAccountRegistration);
		this.submitAccountRegistration.sendKeys(submitAccountRegistration);
	}
}
