package com.HBFramework.PageObject;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.HBFramework.helper.Logger.LoggerHelper;
import com.HBFramework.helper.Wait.WaitHelper;
import com.HBFramework.testbase.Config;
import com.HBFramework.testbase.baseTest;

public class HomePage {

	WebDriver driver;
	WaitHelper wait;
	private final Logger log = LoggerHelper.getLogger(LoginPage.class);

	String Women= "Women";
	String Dresses= "Dresses";
	String Tshirt= "T-shirts";
	String Blouses= "Blouses";
	String CasualDresses= "Casual Dresses";

	@FindBy(xpath=".//*[@id='block_top_menu']/ul/li[1]/a")
	WebElement womenMenu;

	@FindBy(xpath=".//*[@id='block_top_menu']/ul/li[2]/a")
	WebElement dressMenu;

	@FindBy(xpath=".//*[@id='block_top_menu']/ul/li[3]/a")
	WebElement tshirtMenu;

	public HomePage(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
		wait= new WaitHelper(driver);
		wait.waitForElement(driver, womenMenu, new Config(baseTest.prop).getExplicitWait());
	}

	public void mouseOver(String data){
		log.info("doing mouse over on :"+data);
		Actions action= new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath(".//*[Contains(text(), '"+data+"']"))).build().perform();
	}

	public ProductCategoryPage clickOnItem(String data){
		log.info("clickOnItem  :"+data);
		wait.waitForElement(driver, driver.findElement(By.xpath(".//*[Contains(text(), '"+data+"']")), new Config(baseTest.prop).getExplicitWait());
		driver.findElement(By.xpath(".//*[Contains(text(), '"+data+"']")).click();
		return new ProductCategoryPage(driver);	
	}

	public ProductCategoryPage clickOnMenu(WebElement ele){
		log.info("clickOnMenu  :"+ele.getText());
		ele.click();
		return new ProductCategoryPage(driver);

	}
}
