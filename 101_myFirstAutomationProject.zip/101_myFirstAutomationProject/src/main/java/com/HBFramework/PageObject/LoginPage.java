package com.HBFramework.PageObject;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.HBFramework.helper.Javascript.JavaScriptHelper;
import com.HBFramework.helper.Logger.LoggerHelper;
import com.HBFramework.helper.Wait.WaitHelper;
import com.HBFramework.helper.genericHelper.GenericHelper;
import com.HBFramework.testbase.Config;
import com.HBFramework.testbase.baseTest;

public class LoginPage {

	WebDriver driver;
	WaitHelper wait;
	private final Logger log = LoggerHelper.getLogger(LoginPage.class);

	@FindBy(xpath=".//*[@id='header']/div[2]/div/div/nav/div[1]/a")
	WebElement signin;

	@FindBy(xpath=".//*[@id='email']")
	WebElement emailAddress;

	@FindBy(xpath=".//*[@id='passwd']")
	WebElement passWord;

	@FindBy(xpath=".//*[@id='SubmitLogin']")
	WebElement submitLogin;

	@FindBy(xpath="//*[@id='center_column']/p")
	WebElement successMsgObject;

	@FindBy(xpath=".//*[@id='email_create']")
	WebElement registration;

	@FindBy(xpath=".//*[@id='SubmitCreate']")
	WebElement createAnAccount;

	public LoginPage(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
		wait =new WaitHelper(driver);
		wait.waitForElement(driver, signin, new Config(baseTest.prop).getExplicitWait());
	}

	public void clickOnSignIn(){
		log.info("clicked on sign in link...");
		signin.click();
	}

	public void enterEmailAddress(String emailAddress){
		log.info("Enter emailAddress :"+emailAddress);
		this.emailAddress.sendKeys(emailAddress);
	}

	public void enterPassword(String password){
		log.info("Entering password...."+password);
		this.passWord.sendKeys(password);
	}

	public HomePage clickOnSubmitButton(){
		log.info("clicking on submit button...");
		new JavaScriptHelper(driver).scrollDownVertically();
		submitLogin.click();
		return new HomePage(driver);
	}

	public boolean verifySuccessLoginMsg(){
		return new GenericHelper().isDisplayed(successMsgObject);
	}

	public void enterRegistrationEmail(){
		String email = System.currentTimeMillis()+"@gmail.com";
		log.info("entering registration email.."+email);
		registration.sendKeys(email);
	}

	public RegistrationPage clickOnCreateAnAccount(){
		createAnAccount.click();
		return new RegistrationPage(driver);
	}

	public void loginToApplication(String emailAddress,String password){
		clickOnSignIn();
		enterEmailAddress(emailAddress);
		enterPassword(password);
		clickOnSubmitButton();
	}
}












