package com.HBFramework.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class ResourceHelper {

	public static String getResourcePath(String resorcePath) {
		String path = getBaseResourcePath()+resorcePath;
		return path;
	}

	public static String getBaseResourcePath(){
		String bpath=System.getProperty("user.dir");
		return bpath;
	}

	public static InputStream getResourcePathInputStream(String Ipath) throws FileNotFoundException {
		String IOpath= getBaseResourcePath()+Ipath;
		return new FileInputStream(IOpath);
	}
}
