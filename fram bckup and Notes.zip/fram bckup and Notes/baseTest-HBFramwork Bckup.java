package com.HBFramework.testbase;

import java.io.FileInputStream;


import java.io.IOException;
//import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.HBFramework.excel_lib.Excel_reader;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class baseTest {
	public static WebDriver driver = null;
	public static Properties prop = null;
	public static FileInputStream file = null;
	public static ExtentReports extent=null;
	public static ExtentTest test=null;
	public Excel_reader Exls;

	public ITestResult result;//new thing: testng interface

	static {//or else i can use zohoframwework extentmanager
		Calendar cal =Calendar.getInstance();
		SimpleDateFormat formater= new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		if (extent==null) {
			extent= new ExtentReports(System.getProperty("user.dir")+ "\\src\\main\\java\\com\\HBFramework\\reports\\REPORT_"+formater.format(cal.getTime())+".html" ,false, DisplayOrder.NEWEST_FIRST);
		}
	}

	public void getBrowser(String browserType) throws IOException{
		try {
			if (System.getProperty("os.name").contains("Window")) {
				if(driver==null){
					if (browserType.equalsIgnoreCase(prop.getProperty(browserType))) {
						System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+ "\\drivers\\IEDriverServer.exe");
						driver = new InternetExplorerDriver();
					}else if(browserType.equalsIgnoreCase(prop.getProperty(browserType))){	
						System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
						driver= new ChromeDriver();	
					}else if(browserType.equalsIgnoreCase("FF")){
						System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"\\drivers\\geckodriver.exe");
						driver = new FirefoxDriver();
					}
					driver.manage().window().maximize();
					driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				}		
			}
		}
		catch (Exception e) {
			test.log(LogStatus.FAIL, "invalid browserType!!");
			getScreenShot(e.getMessage()); 
			Assert.fail();
		}


	}
	public void loadPropertiesFile() throws Exception{	
		try {
			String filePath = System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\config\\config.properties";
			file=new FileInputStream(filePath);
			prop=new Properties();
			prop.load(file);
		} catch (Exception e) {		
			e.printStackTrace();
			test.log(LogStatus.FAIL, "invalid config property name!!");
			getScreenShot("configError");
			Assert.fail();
		}
		/*prop= new Properties();
		String filePath = System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\config\\config.properties";
		file = new FileInputStream(filePath);
		prop.load(file);*/


		String filePath1 = System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\config\\OR.properties";
		file = new FileInputStream(filePath1);
		prop.load(file);	 
	}
	public String getScreenShot(String imagename) throws IOException{
		if (imagename=="") {
			imagename= "blank_error";	
		}
		File image =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String imageLocation= System.getProperty("user.dir")+ "\\screenshots"; 
		Calendar cal =Calendar.getInstance();
		SimpleDateFormat formater= new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String actualimagename=imageLocation+imagename+"_"+formater.format(cal.getTime())+".PNG";
		FileUtils.copyFile(image, new File(actualimagename));
		return actualimagename;
	}
	public WebElement waitForElement(WebDriver ldriver, long time, WebElement element){
		WebDriverWait wait= new WebDriverWait(ldriver, time);
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	public WebElement waitForElementWithPollingInterval(WebDriver ldriver, long time, WebElement element){
		WebDriverWait wait= new WebDriverWait(ldriver, time);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		wait.ignoring(NoSuchElementException.class);
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	public void implicitWait(long time){
		driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
	}
	public void getResult(ITestResult result) throws IOException   {
		if (result.getStatus()==ITestResult.SUCCESS) {
			test.log(LogStatus.PASS, result.getName(), "mytest is passed");	
		}else if (result.getStatus()==ITestResult.SKIP) {
			test.log(LogStatus.SKIP, result.getName() +" mytest skip reason is"+ result.getThrowable());
		}else if (result.getStatus()==ITestResult.FAILURE) {
			test.log(LogStatus.FAIL, result.getName() +" mytest failed reason is"+ result.getThrowable());
			String screen = getScreenShot("");
			test.log(LogStatus.FAIL, test.addScreenCapture(screen));
		}else if (result.getStatus()==ITestResult.STARTED) {
			test.log(LogStatus.INFO, result.getTestName()+"mytest is started");
		}
	}
	@BeforeMethod
	public void beforeMethod(){ 	//provides information about, and access to, a single method on a class 
		//reflected method may be a class method or an instance method (including an abstract method). 
		//it throws an IllegalArgumentException if a narrowing conversion would occur.[import java.lang.reflect.Method;s]
		/*extent.startTest(result.getName(), "beforemethod--startTest--> ");
		test.log(LogStatus.INFO, result.getName() + "beforemethod--log-->mytest is started");*/
		extent.startTest("loginAccountTestCase", "picking the login testdata from excel");
		test.log(LogStatus.INFO, "login test has started");
	}
	@AfterMethod
	public void afterMethod(ITestResult result) throws IOException{
		getResult(result);
	}
	@AfterClass(alwaysRun=true)
	public void endTest(){
		//driver.quit();
		extent.endTest(test);
		extent.flush();

	}
	public void navigator(String appUrl){
		driver.navigate().to(prop.getProperty(appUrl));
	}
	public void switchwindow(int index){
		driver.switchTo().frame(index);	
	}
	public WebElement getElement(String locatorkey){
		try {
			if (locatorkey.endsWith("_xpath")) {
				return driver.findElement(By.xpath(locatorkey));}
			if (locatorkey.endsWith("_id")) {
				return driver.findElement(By.xpath(locatorkey));}
			if (locatorkey.endsWith("_name")) {
				return driver.findElement(By.xpath(locatorkey));}
			else{
				System.out.println("locator not correct!!");
				test.log(LogStatus.FAIL, "invalid locator provided!!");
				//testfail(locatorkey+"invalid locator provided!!");	 // testfail() chetan created			
				return null;
			}
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "invalid locator provided!!" +e.getMessage());
			return null;
		}


	}
	public void setText(String locatorkey, String inpputtext){
		WebElement wEle= getElement(locatorkey);
		wEle.clear();
		wEle.sendKeys(inpputtext);
	}
	public void click(String locatorkey){
		WebElement wEle= getElement(locatorkey);
		wEle.click();

	}
	public boolean verifyText(String actValue,String expValue){
		if(actValue.equals(expValue)){
			return true;
		}else{
			return false;
		}
	}
	public Object[][] getExcelData(String excelname, String sheetname ){
		String excellocation =System.getProperty("user.dir")+"\\src\\main\\java\\com\\HBFramework\\testdata\\"+excelname;
		Exls = new Excel_reader();
		Object[][] data =Exls.readExcelData(excellocation, sheetname);
		return data;
	}

	/*public static void main(String[] args) throws Exception {
		baseTest b1 = new baseTest();
		//b1.getBrowser("ie");
		b1.loadPropertiesFile();
		System.out.println(prop.getProperty("url"));

	}*/
}


